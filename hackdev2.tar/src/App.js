import React from 'react';
import MetamaskBtn from './MetamaskBtn'
import Home from './components/Home';


const App = () => {
  return (
    <>
      <Home />
    </>
  );
};

export default App;
